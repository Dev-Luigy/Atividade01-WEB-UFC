import './App.css';

import MyNavbar from "./components/mynavbar/MyNavbar.js";
import Main from "./components/CRUD//Main.js";

function App() {
  return (
    <div className="App">
      <Main />
    </div>
  );
}

export default App;
