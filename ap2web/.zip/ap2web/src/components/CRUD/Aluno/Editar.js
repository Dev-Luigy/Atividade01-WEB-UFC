const Editar = () =>{
    return(
        <h1>
            Editar Aluno
        </h1>
    )
}

export default Editar