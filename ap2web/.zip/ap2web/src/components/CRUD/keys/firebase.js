const firebaseConfig = {
  apiKey: "AIzaSyAHiKvSSoAzhJ7-u3E-WfOvp2-3hm-s8FU",
  authDomain: "web-2-b213a.firebaseapp.com",
  projectId: "web-2-b213a",
  storageBucket: "web-2-b213a.appspot.com",
  messagingSenderId: "826020394739",
  appId: "1:826020394739:web:17a088cb02d260d72be986",
  measurementId: "G-EYLEHCHY7Z"
};
export default firebaseConfig
// Initialize Firebase
